#include <string>
#include <vector>

using namespace std;

void entramado(int n, int m, int l, int k, vector<int> &a, vector<int> &b, vector<int> &compuertas) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
