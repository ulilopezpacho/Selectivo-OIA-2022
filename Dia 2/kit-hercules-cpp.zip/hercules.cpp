#include <string>
#include <vector>

using namespace std;

long long hercules(long long H, vector<int> &c, vector<int> &d, vector<int> &r, vector<int> &e, vector<int> &u) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
