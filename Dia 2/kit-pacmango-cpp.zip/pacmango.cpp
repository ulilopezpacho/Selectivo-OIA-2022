#include <string>
#include <vector>

using namespace std;

int pacmango(vector<int> &a, vector<int> & b, int P, int S, vector<int> &F, vector<int> &movimientos) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
