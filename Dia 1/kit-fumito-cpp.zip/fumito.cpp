#include <vector>
#include <cassert>

using namespace std;

int sentir(int postePrincip, int posteSecun);
void destruir(int poste1, int poste2, int poste3);

void fumito(vector<int> &x, vector<int> &y) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
