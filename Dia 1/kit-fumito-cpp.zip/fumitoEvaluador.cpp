#include <iostream>
#include <vector>

using namespace std;

int sentir(int postePrincip, int posteSecun) {
    cout << "sentir(" << postePrincip << "," << posteSecun << ")" << endl;
    int ret;
    cin >> ret;
    return ret;
}

void destruir(int poste1, int poste2, int poste3) {
    cout << "destruir(" << poste1 << "," << poste2 << "," << poste3 << ")" << endl;
}

void fumito(vector<int> &x, vector<int> &y);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    vector<int> x(n), y(n);
    for(int i=0;i<n;i++)
        cin >> x[i] >> y[i];
    fumito(x,y);
    return 0;
}
