#include <string>
#include <vector>

using namespace std;

string minarbol(string &s) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
